def calculate_bmi(weight, height):
    bmi = weight / (height ** 2)
    return bmi

def interpret_bmi(bmi):
    """
    Interprets the BMI and returns a corresponding category.
    """
    if bmi < 18.5:
        return "Underweight"
    elif bmi < 25:
        return "Normal weight"
    elif bmi < 30:
        return "Overweight"
    else:
        return "Obese"

# Prompt the user for weight and height
weight = float(input("Enter your weight in kilograms (kg): "))
height = float(input("Enter your height in meters (m): "))

# Calculate the BMI
bmi = calculate_bmi(weight, height)

# Interpret the BMI category
category = interpret_bmi(bmi)

# Open a text file in write mode
with open("bmi_result.txt", "w") as file:
    # Write the result to the file
    file.write("BMI Calculation Result:\n")
    file.write("Weight: {:.2f} kg\n".format(weight))
    file.write("Height: {:.2f} m\n".format(height))
    file.write("BMI: {:.2f}\n".format(bmi))
    file.write("Category: {}\n".format(category))

# Print the result and category
print("BMI: {:.2f}".format(bmi))
print("Category: {}".format(category))
print("BMI result has been saved to 'bmi_result.txt'")
